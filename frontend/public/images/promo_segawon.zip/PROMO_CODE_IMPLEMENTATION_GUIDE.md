# 💎 Promo Code System - Complete Implementation Guide

## 🎯 Architecture Overview

### **Design Philosophy:**
- ✅ **Calculate outside DB** - All pricing logic in backend
- ✅ **Store snapshots** - Save final prices in orders
- ✅ **Flexible & maintainable** - Easy to change pricing rules

---

## 📊 Database Design

### **What We Store in Database:**

**Products table:**
```
- base_price (cost from supplier)
- selling_price_qris (base selling price for QRIS)
- selling_price_va (base selling price for VA)
- selling_price_ewallet (base selling price for E-wallet)
```

**Orders table (snapshot at order time):**
```
- amount (product base price)
- admin_fee (admin fee at order time)
- payment_fee (gateway fee)
- subtotal (before discount)
- promo_code (code used)
- promo_discount (discount amount)
- discount_amount (total all discounts)
- total_amount (final amount to pay)
```

**Promo codes table:**
```
- code (unique promo code)
- discount_type (percentage/fixed_amount)
- discount_value (10 for 10% or 50000 for Rp 50K)
- max_discount_amount (cap for percentage)
- min_order_amount (minimum to use promo)
- usage limits & validity
```

---

## 🔄 Price Calculation Flow

```
1. User selects product
   ↓
2. User selects payment method
   ↓
3. Backend gets base price (from DB)
   ↓
4. Backend calculates payment fee (logic in code)
   ↓
5. Backend calculates subtotal
   ↓
6. User enters promo code (optional)
   ↓
7. Backend validates promo
   ↓
8. Backend calculates discount
   ↓
9. Backend calculates final total
   ↓
10. Save snapshot to order (DB)
```

---

## 🚀 Implementation Steps

### **Step 1: Database Schema**

**Execute SQL:**
```bash
# Add to database/promo_code_schema.sql
```

This creates:
- `promo_codes` table
- `promo_code_usage` table
- Validation function `is_promo_code_valid()`
- Triggers for usage tracking
- Sample promo codes

---

### **Step 2: Price Calculator Service**

**Create:** `backend/services/PriceCalculator.js`

**Key functions:**
- `calculateFinalPrice()` - Main calculation
- `getBasePriceByPaymentMethod()` - Get base price
- `calculatePaymentFee()` - Gateway fee logic
- `applyPromoCode()` - Validate & calculate discount
- `recordPromoUsage()` - Track usage
- `createOrderSnapshot()` - Save to DB

---

### **Step 3: API Routes**

**Create:** `backend/routes/promo.js`

**Endpoints:**

**Public:**
- `POST /api/calculate-price` - Calculate final price
- `POST /api/promo/validate` - Validate promo code
- `GET /api/promo/active` - Get active promos

**Admin:**
- `POST /api/admin/promo` - Create promo
- `GET /api/admin/promo/:code/stats` - Usage stats

---

### **Step 4: Update Order Creation**

**Modify:** `backend/routes/order.js`

```javascript
const PriceCalculator = require('../services/PriceCalculator');

router.post('/create', async (req, res) => {
  const { productId, paymentMethod, promoCode, customerEmail } = req.body;
  
  // Calculate price with promo
  const priceResult = await PriceCalculator.calculateFinalPrice({
    productId,
    paymentMethod,
    promoCode,
    customerEmail
  });
  
  if (!priceResult.success) {
    return res.status(400).json({ error: priceResult.error });
  }
  
  const breakdown = priceResult.breakdown;
  
  // Create order
  const order = await db.query(`
    INSERT INTO orders (
      product_id, payment_method,
      amount, admin_fee, payment_fee,
      subtotal, promo_code, promo_discount,
      discount_amount, total_amount,
      customer_email, ...
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, ...)
    RETURNING *
  `, [
    productId,
    paymentMethod,
    breakdown.product.basePrice,
    breakdown.fees.adminFee,
    breakdown.fees.paymentFee,
    breakdown.subtotal,
    breakdown.promo?.code,
    breakdown.discount,
    breakdown.discount,
    breakdown.total,
    customerEmail,
    ...
  ]);
  
  // Record promo usage if used
  if (breakdown.promo) {
    await PriceCalculator.recordPromoUsage({
      promoCode: breakdown.promo.code,
      orderId: order.rows[0].id,
      customerEmail,
      userIp: req.ip,
      discountAmount: breakdown.discount
    });
  }
  
  // Continue with payment gateway...
});
```

---

## 📱 Frontend Integration

### **Checkout Flow:**

```javascript
// 1. Get product pricing
const getPricing = async (productId) => {
  const response = await fetch('/api/products/' + productId);
  const product = await response.json();
  
  return {
    qris: product.selling_price_qris,
    va: product.selling_price_va,
    ewallet: product.selling_price_ewallet
  };
};

// 2. Calculate price with payment method
const [pricing, setPricing] = useState(null);
const [promoCode, setPromoCode] = useState('');
const [promoApplied, setPromoApplied] = useState(null);

const calculatePrice = async () => {
  const response = await fetch('/api/calculate-price', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      productId,
      paymentMethod,
      promoCode: promoCode || undefined,
      customerEmail
    })
  });
  
  const result = await response.json();
  
  if (result.success) {
    setPricing(result.breakdown);
    if (result.breakdown.promo) {
      setPromoApplied(result.breakdown.promo);
    }
  }
};

// 3. Apply promo code
const applyPromo = async () => {
  const response = await fetch('/api/promo/validate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      promoCode,
      orderAmount: pricing.subtotal,
      customerEmail
    })
  });
  
  const result = await response.json();
  
  if (result.valid) {
    // Recalculate with promo
    await calculatePrice();
    toast.success('Promo code applied!');
  } else {
    toast.error(result.error);
  }
};

// 4. Display breakdown
return (
  <div className="price-breakdown">
    <div className="line-item">
      <span>{pricing.product.name}</span>
      <span>Rp {pricing.product.basePrice.toLocaleString()}</span>
    </div>
    
    <div className="line-item">
      <span>Payment Fee</span>
      <span>Rp {pricing.fees.paymentFee.toLocaleString()}</span>
    </div>
    
    {pricing.fees.adminFee > 0 && (
      <div className="line-item">
        <span>Admin Fee</span>
        <span>Rp {pricing.fees.adminFee.toLocaleString()}</span>
      </div>
    )}
    
    <div className="line-item subtotal">
      <span>Subtotal</span>
      <span>Rp {pricing.subtotal.toLocaleString()}</span>
    </div>
    
    {pricing.promo && (
      <div className="line-item discount">
        <span>Promo: {pricing.promo.code}</span>
        <span>- Rp {pricing.discount.toLocaleString()}</span>
      </div>
    )}
    
    <div className="line-item total">
      <span>Total</span>
      <span>Rp {pricing.total.toLocaleString()}</span>
    </div>
    
    <div className="promo-input">
      <input 
        type="text"
        placeholder="Promo code"
        value={promoCode}
        onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
      />
      <button onClick={applyPromo}>Apply</button>
    </div>
  </div>
);
```

---

## 🎯 Promo Code Examples

### **1. Percentage Discount**

```sql
INSERT INTO promo_codes (
  code, description, discount_type, discount_value,
  max_discount_amount, min_order_amount, max_usage_total
) VALUES (
  'WELCOME10',
  'Welcome 10% discount for new users',
  'percentage',
  10,
  50000,  -- Max discount Rp 50K
  20000,  -- Min order Rp 20K
  1000    -- 1000 users can use
);
```

**Example calculation:**
- Order: Rp 150,000
- Discount: 10% = Rp 15,000 (within max)
- Final: Rp 135,000

---

### **2. Fixed Amount Discount**

```sql
INSERT INTO promo_codes (
  code, description, discount_type, discount_value,
  min_order_amount, max_usage_per_user
) VALUES (
  'SAVE50K',
  'Save Rp 50,000',
  'fixed_amount',
  50000,
  100000,  -- Min order Rp 100K
  1        -- Once per user
);
```

**Example calculation:**
- Order: Rp 150,000
- Discount: Rp 50,000 (fixed)
- Final: Rp 100,000

---

### **3. Limited Time Promo**

```sql
INSERT INTO promo_codes (
  code, description, discount_type, discount_value,
  valid_until, max_usage_total
) VALUES (
  'FLASH20',
  'Flash sale 20% off',
  'percentage',
  20,
  CURRENT_TIMESTAMP + INTERVAL '24 hours',
  500
);
```

---

## ✅ Benefits of This Approach

### **1. Flexibility**
- Change pricing logic without DB migration
- A/B test different pricing
- Dynamic fees based on external factors

### **2. Accuracy**
- All calculations in one place
- Consistent across application
- Easy to audit

### **3. Performance**
- No complex DB queries for calculation
- Calculation happens once per order
- Snapshot stored for history

### **4. Maintainability**
- Single source of truth (PriceCalculator)
- Easy to add new discount types
- Clear separation of concerns

---

## 🔧 Testing

### **Test Cases:**

```javascript
// Test 1: Basic price calculation
const test1 = await PriceCalculator.calculateFinalPrice({
  productId: 'product-uuid',
  paymentMethod: 'qris'
});
// Expected: basePrice + 0.7% fee

// Test 2: With promo code
const test2 = await PriceCalculator.calculateFinalPrice({
  productId: 'product-uuid',
  paymentMethod: 'qris',
  promoCode: 'WELCOME10'
});
// Expected: (basePrice + fee) - 10% discount

// Test 3: Invalid promo
const test3 = await PriceCalculator.calculateFinalPrice({
  productId: 'product-uuid',
  paymentMethod: 'qris',
  promoCode: 'INVALID'
});
// Expected: success: false, error message

// Test 4: Promo with minimum order
const test4 = await PriceCalculator.calculateFinalPrice({
  productId: 'cheap-product',  // Only Rp 10K
  paymentMethod: 'qris',
  promoCode: 'WELCOME10'  // Requires min Rp 20K
});
// Expected: Promo invalid due to min order

// Test 5: Max discount cap
const test5 = await PriceCalculator.calculateFinalPrice({
  productId: 'expensive-product',  // Rp 1jt
  paymentMethod: 'qris',
  promoCode: 'WELCOME10'  // 10% with max Rp 50K
});
// Expected: Discount capped at Rp 50K
```

---

## 📊 Admin Dashboard Features

### **Promo Management:**

```javascript
// Get all promo codes with stats
GET /api/admin/promo

// Create new promo
POST /api/admin/promo
{
  "code": "NEWYEAR25",
  "discountType": "percentage",
  "discountValue": 25,
  "maxUsageTotal": 1000,
  "validUntil": "2025-01-31T23:59:59Z"
}

// View promo usage
GET /api/admin/promo/NEWYEAR25/stats

Response:
{
  "totalUses": 234,
  "uniqueUsers": 189,
  "totalDiscount": 4567000,
  "avgDiscount": 19500,
  "topUsers": [...]
}

// Deactivate promo
PATCH /api/admin/promo/NEWYEAR25
{ "isActive": false }
```

---

## 🎉 Summary

**Database:**
- Stores base prices only
- Stores promo code rules
- Stores order snapshots (final prices)

**Backend:**
- Calculates all pricing dynamically
- Validates promo codes
- Records usage
- Creates order snapshots

**Benefits:**
- ✅ Flexible pricing
- ✅ Easy to maintain
- ✅ Accurate calculations
- ✅ Complete audit trail
- ✅ Scalable

---

## 📁 Files Provided

1. ✅ `promo_code_schema.sql` - Database schema
2. ✅ `PriceCalculator.js` - Price calculation service
3. ✅ `promoRoutes.js` - API endpoints
4. ✅ This guide - Complete implementation

**Ready to implement!** 🚀
