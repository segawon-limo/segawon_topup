/**
 * Price Calculation Service
 * 
 * Best Practice: All pricing logic happens here!
 * Database only stores base prices.
 * 
 * Flow:
 * 1. Get product base price
 * 2. Apply payment method fee
 * 3. Apply promo code
 * 4. Calculate final total
 * 5. Save snapshot to order
 */

const db = require('../config/database');

class PriceCalculator {
  
  /**
   * Main calculation function
   * @param {Object} params
   * @returns {Object} Complete price breakdown
   */
  static async calculateFinalPrice(params) {
    const {
      productId,
      paymentMethod,     // 'qris', 'va', 'ewallet'
      paymentChannel,    // 'bca_va', 'gopay', etc
      promoCode = null,
      customerEmail = null
    } = params;

    try {
      // Step 1: Get product
      const product = await this.getProduct(productId);
      if (!product) {
        throw new Error('Product not found');
      }

      // Step 2: Get base price by payment method
      const basePrice = this.getBasePriceByPaymentMethod(product, paymentMethod);

      // Step 3: Calculate payment fees
      const paymentFee = this.calculatePaymentFee(basePrice, paymentMethod, paymentChannel);

      // Step 4: Calculate admin fee (if any)
      const adminFee = await this.getAdminFee();

      // Step 5: Calculate subtotal (before promo)
      const subtotal = basePrice + paymentFee + adminFee;

      // Step 6: Apply promo code discount
      let promoDiscount = 0;
      let promoDetails = null;

      if (promoCode) {
        const promoResult = await this.applyPromoCode({
          promoCode,
          productId,
          subtotal,
          customerEmail
        });

        if (promoResult.valid) {
          promoDiscount = promoResult.discount;
          promoDetails = promoResult.details;
        } else {
          // Return error if promo invalid but provided
          return {
            success: false,
            error: promoResult.error
          };
        }
      }

      // Step 7: Calculate final total
      const finalTotal = subtotal - promoDiscount;

      // Step 8: Return complete breakdown
      return {
        success: true,
        breakdown: {
          product: {
            id: product.id,
            name: product.name,
            sku: product.sku,
            basePrice: basePrice
          },
          fees: {
            paymentFee: paymentFee,
            adminFee: adminFee
          },
          subtotal: subtotal,
          promo: promoDetails ? {
            code: promoDetails.code,
            description: promoDetails.description,
            discountType: promoDetails.discount_type,
            discountValue: promoDetails.discount_value,
            discountAmount: promoDiscount
          } : null,
          discount: promoDiscount,
          total: finalTotal,
          payment: {
            method: paymentMethod,
            channel: paymentChannel
          }
        }
      };

    } catch (error) {
      console.error('Price calculation error:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Get product from database
   */
  static async getProduct(productId) {
    const result = await db.query(
      'SELECT * FROM products WHERE id = $1 AND is_active = true',
      [productId]
    );
    return result.rows[0] || null;
  }

  /**
   * Get base price based on payment method
   */
  static getBasePriceByPaymentMethod(product, paymentMethod) {
    const priceMap = {
      'qris': product.selling_price_qris,
      'va': product.selling_price_va,
      'ewallet': product.selling_price_ewallet
    };

    const price = priceMap[paymentMethod] || product.selling_price_qris;
    return parseFloat(price);
  }

  /**
   * Calculate payment gateway fee
   * 
   * Fee structure:
   * - QRIS: 0.7%
   * - VA: 0.7% + Rp 1,000
   * - E-wallet: 2%
   */
  static calculatePaymentFee(amount, paymentMethod, paymentChannel) {
    const feeStructure = {
      'qris': {
        percentage: 0.7,
        fixed: 0
      },
      'va': {
        percentage: 0.7,
        fixed: 1000
      },
      'ewallet': {
        percentage: 2.0,
        fixed: 0
      }
    };

    const fee = feeStructure[paymentMethod] || { percentage: 0, fixed: 0 };
    
    const calculatedFee = (amount * fee.percentage / 100) + fee.fixed;
    
    return Math.round(calculatedFee); // Round to nearest Rupiah
  }

  /**
   * Get admin fee from settings
   */
  static async getAdminFee() {
    const result = await db.query(
      "SELECT setting_value FROM settings WHERE setting_key = 'admin_fee'"
    );
    
    if (result.rows[0]) {
      return parseInt(result.rows[0].setting_value) || 0;
    }
    
    return 0; // Default no admin fee
  }

  /**
   * Apply promo code and calculate discount
   */
  static async applyPromoCode({ promoCode, productId, subtotal, customerEmail }) {
    // Validate promo code
    const validationResult = await db.query(
      'SELECT * FROM is_promo_code_valid($1, $2, $3)',
      [promoCode.toUpperCase(), customerEmail, subtotal]
    );

    const validation = validationResult.rows[0];

    if (!validation.is_valid) {
      return {
        valid: false,
        error: validation.message
      };
    }

    // Get full promo details
    const promoResult = await db.query(
      'SELECT * FROM promo_codes WHERE code = $1',
      [promoCode.toUpperCase()]
    );

    const promo = promoResult.rows[0];

    // Calculate discount amount
    let discount = 0;

    if (promo.discount_type === 'percentage') {
      // Percentage discount
      discount = subtotal * (parseFloat(promo.discount_value) / 100);
      
      // Apply max discount cap
      if (promo.max_discount_amount) {
        discount = Math.min(discount, parseFloat(promo.max_discount_amount));
      }
    } else if (promo.discount_type === 'fixed_amount') {
      // Fixed amount discount
      discount = parseFloat(promo.discount_value);
    }

    // Ensure discount doesn't exceed subtotal
    discount = Math.min(discount, subtotal);
    discount = Math.round(discount);

    return {
      valid: true,
      discount: discount,
      details: promo
    };
  }

  /**
   * Record promo usage in database
   */
  static async recordPromoUsage({ promoCode, orderId, customerEmail, userIp, discountAmount }) {
    // Get promo code ID
    const promoResult = await db.query(
      'SELECT id FROM promo_codes WHERE code = $1',
      [promoCode.toUpperCase()]
    );

    if (promoResult.rows.length === 0) {
      return;
    }

    const promoId = promoResult.rows[0].id;

    // Insert usage record
    await db.query(`
      INSERT INTO promo_code_usage (
        promo_code_id, 
        order_id, 
        user_email, 
        user_ip, 
        discount_amount
      ) VALUES ($1, $2, $3, $4, $5)
    `, [promoId, orderId, customerEmail, userIp, discountAmount]);
  }

  /**
   * Get pricing for display (without calculation)
   */
  static async getProductPricing(productId) {
    const product = await this.getProduct(productId);
    
    if (!product) {
      return null;
    }

    return {
      qris: parseFloat(product.selling_price_qris),
      va: parseFloat(product.selling_price_va),
      ewallet: parseFloat(product.selling_price_ewallet),
      recommended: 'qris' // Cheapest option
    };
  }

  /**
   * Create order snapshot
   * This saves the calculated prices at the time of order
   */
  static async createOrderSnapshot(breakdown, orderId) {
    await db.query(`
      UPDATE orders SET
        amount = $1,
        admin_fee = $2,
        total_amount = $3,
        promo_code = $4,
        promo_discount = $5,
        subtotal = $6,
        discount_amount = $7,
        payment_fee = $8
      WHERE id = $9
    `, [
      breakdown.product.basePrice,
      breakdown.fees.adminFee,
      breakdown.total,
      breakdown.promo ? breakdown.promo.code : null,
      breakdown.promo ? breakdown.promo.discountAmount : 0,
      breakdown.subtotal,
      breakdown.discount,
      breakdown.fees.paymentFee,
      orderId
    ]);
  }
}

module.exports = PriceCalculator;
