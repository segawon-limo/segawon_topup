-- =====================================================
-- PROMO CODE SYSTEM - Best Practice Schema
-- =====================================================

-- Promo Codes Table
CREATE TABLE promo_codes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Code Details
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    
    -- Discount Settings
    discount_type VARCHAR(20) NOT NULL, -- 'percentage', 'fixed_amount'
    discount_value DECIMAL(10,2) NOT NULL,
    max_discount_amount DECIMAL(10,2), -- Cap untuk percentage discount
    min_order_amount DECIMAL(10,2), -- Minimum order untuk pakai promo
    
    -- Usage Limits
    max_usage_total INT, -- Total usage limit (NULL = unlimited)
    max_usage_per_user INT DEFAULT 1, -- Per user limit
    current_usage_count INT DEFAULT 0, -- Track total usage
    
    -- Validity Period
    valid_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_until TIMESTAMP,
    
    -- Conditions
    applicable_products JSONB, -- Array of product IDs or categories
    applicable_payment_methods JSONB, -- Array of payment methods
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    
    -- Metadata
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Promo Code Usage History
CREATE TABLE promo_code_usage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    promo_code_id UUID REFERENCES promo_codes(id) ON DELETE CASCADE,
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    
    -- User info (could be email for non-registered users)
    user_email VARCHAR(255),
    user_ip VARCHAR(50),
    
    -- Discount applied
    discount_amount DECIMAL(10,2) NOT NULL,
    
    used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add promo code fields to orders table
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS promo_code VARCHAR(50),
ADD COLUMN IF NOT EXISTS promo_discount DECIMAL(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS subtotal DECIMAL(10,2), -- Before discount
ADD COLUMN IF NOT EXISTS discount_amount DECIMAL(10,2) DEFAULT 0; -- Total all discounts

-- Indexes for performance
CREATE INDEX idx_promo_codes_code ON promo_codes(code);
CREATE INDEX idx_promo_codes_active ON promo_codes(is_active, valid_until);
CREATE INDEX idx_promo_usage_code ON promo_code_usage(promo_code_id);
CREATE INDEX idx_promo_usage_email ON promo_code_usage(user_email);

-- Function to check promo code validity
CREATE OR REPLACE FUNCTION is_promo_code_valid(
    p_code VARCHAR(50),
    p_user_email VARCHAR(255),
    p_order_amount DECIMAL(10,2)
)
RETURNS TABLE (
    is_valid BOOLEAN,
    discount_type VARCHAR(20),
    discount_value DECIMAL(10,2),
    max_discount DECIMAL(10,2),
    message TEXT
) AS $$
DECLARE
    v_promo RECORD;
    v_usage_count INT;
BEGIN
    -- Get promo code
    SELECT * INTO v_promo 
    FROM promo_codes 
    WHERE code = p_code 
    AND is_active = true;
    
    -- Check if exists
    IF v_promo IS NULL THEN
        RETURN QUERY SELECT false, NULL::VARCHAR, NULL::DECIMAL, NULL::DECIMAL, 'Promo code not found'::TEXT;
        RETURN;
    END IF;
    
    -- Check if expired
    IF v_promo.valid_until IS NOT NULL AND v_promo.valid_until < CURRENT_TIMESTAMP THEN
        RETURN QUERY SELECT false, NULL::VARCHAR, NULL::DECIMAL, NULL::DECIMAL, 'Promo code has expired'::TEXT;
        RETURN;
    END IF;
    
    -- Check if not yet valid
    IF v_promo.valid_from > CURRENT_TIMESTAMP THEN
        RETURN QUERY SELECT false, NULL::VARCHAR, NULL::DECIMAL, NULL::DECIMAL, 'Promo code not yet valid'::TEXT;
        RETURN;
    END IF;
    
    -- Check minimum order amount
    IF v_promo.min_order_amount IS NOT NULL AND p_order_amount < v_promo.min_order_amount THEN
        RETURN QUERY SELECT false, NULL::VARCHAR, NULL::DECIMAL, NULL::DECIMAL, 
            format('Minimum order amount is Rp %s', v_promo.min_order_amount)::TEXT;
        RETURN;
    END IF;
    
    -- Check total usage limit
    IF v_promo.max_usage_total IS NOT NULL AND v_promo.current_usage_count >= v_promo.max_usage_total THEN
        RETURN QUERY SELECT false, NULL::VARCHAR, NULL::DECIMAL, NULL::DECIMAL, 'Promo code usage limit reached'::TEXT;
        RETURN;
    END IF;
    
    -- Check per-user usage limit
    IF p_user_email IS NOT NULL THEN
        SELECT COUNT(*) INTO v_usage_count
        FROM promo_code_usage
        WHERE promo_code_id = v_promo.id
        AND user_email = p_user_email;
        
        IF v_promo.max_usage_per_user IS NOT NULL AND v_usage_count >= v_promo.max_usage_per_user THEN
            RETURN QUERY SELECT false, NULL::VARCHAR, NULL::DECIMAL, NULL::DECIMAL, 'You have already used this promo code'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- All checks passed
    RETURN QUERY SELECT true, v_promo.discount_type, v_promo.discount_value, 
                        v_promo.max_discount_amount, 'Promo code valid'::TEXT;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update promo code usage count
CREATE OR REPLACE FUNCTION update_promo_usage_count()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE promo_codes 
    SET current_usage_count = current_usage_count + 1
    WHERE id = NEW.promo_code_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_promo_usage
AFTER INSERT ON promo_code_usage
FOR EACH ROW
EXECUTE FUNCTION update_promo_usage_count();

-- Sample Promo Codes
INSERT INTO promo_codes (
    code, description, discount_type, discount_value, 
    max_discount_amount, min_order_amount, max_usage_total, 
    max_usage_per_user, valid_until
) VALUES 
(
    'WELCOME10', 
    'Welcome discount 10% for new users',
    'percentage', 
    10.00,
    50000, -- Max discount Rp 50K
    20000, -- Min order Rp 20K
    1000, -- Total 1000 users
    1, -- Once per user
    CURRENT_TIMESTAMP + INTERVAL '30 days'
),
(
    'NEWUSER50K',
    'Flat Rp 50K discount for first order',
    'fixed_amount',
    50000,
    NULL, -- No max (already fixed)
    100000, -- Min order Rp 100K
    500, -- Total 500 users
    1, -- Once per user
    CURRENT_TIMESTAMP + INTERVAL '30 days'
),
(
    'VALORANT5',
    '5% discount for Valorant products',
    'percentage',
    5.00,
    25000,
    50000,
    NULL, -- Unlimited usage
    3, -- 3x per user
    CURRENT_TIMESTAMP + INTERVAL '90 days'
);

-- Comments
COMMENT ON TABLE promo_codes IS 'Promo code master data';
COMMENT ON TABLE promo_code_usage IS 'Track promo code usage history';
COMMENT ON COLUMN promo_codes.discount_type IS 'percentage or fixed_amount';
COMMENT ON COLUMN promo_codes.applicable_products IS 'JSON array of product IDs or null for all products';
COMMENT ON COLUMN orders.subtotal IS 'Order amount before any discounts';
COMMENT ON COLUMN orders.discount_amount IS 'Total discount applied (promo + others)';
