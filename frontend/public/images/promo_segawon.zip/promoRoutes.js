/**
 * Promo Code API Routes
 * 
 * Endpoints:
 * - POST /api/calculate-price - Calculate final price with optional promo
 * - POST /api/promo/validate - Validate promo code
 * - GET /api/promo/active - Get active promos
 * - POST /api/admin/promo - Create promo (admin)
 */

const express = require('express');
const router = express.Router();
const PriceCalculator = require('../services/PriceCalculator');
const db = require('../config/database');

/**
 * Calculate final price
 * POST /api/calculate-price
 * 
 * Body:
 * {
 *   "productId": "uuid",
 *   "paymentMethod": "qris",
 *   "paymentChannel": "gopay",  // optional
 *   "promoCode": "WELCOME10",   // optional
 *   "customerEmail": "user@email.com" // optional
 * }
 */
router.post('/calculate-price', async (req, res) => {
  try {
    const { productId, paymentMethod, paymentChannel, promoCode, customerEmail } = req.body;

    // Validate required fields
    if (!productId || !paymentMethod) {
      return res.status(400).json({
        success: false,
        error: 'Product ID and payment method required'
      });
    }

    // Calculate price
    const result = await PriceCalculator.calculateFinalPrice({
      productId,
      paymentMethod,
      paymentChannel,
      promoCode,
      customerEmail
    });

    if (!result.success) {
      return res.status(400).json(result);
    }

    res.json(result);

  } catch (error) {
    console.error('Calculate price error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to calculate price'
    });
  }
});

/**
 * Validate promo code only (without full calculation)
 * POST /api/promo/validate
 * 
 * Body:
 * {
 *   "promoCode": "WELCOME10",
 *   "orderAmount": 100000,
 *   "customerEmail": "user@email.com"
 * }
 */
router.post('/promo/validate', async (req, res) => {
  try {
    const { promoCode, orderAmount, customerEmail } = req.body;

    if (!promoCode || !orderAmount) {
      return res.status(400).json({
        valid: false,
        error: 'Promo code and order amount required'
      });
    }

    // Use database function to validate
    const result = await db.query(
      'SELECT * FROM is_promo_code_valid($1, $2, $3)',
      [promoCode.toUpperCase(), customerEmail, orderAmount]
    );

    const validation = result.rows[0];

    if (!validation.is_valid) {
      return res.json({
        valid: false,
        error: validation.message
      });
    }

    // Calculate discount preview
    let discountAmount = 0;
    if (validation.discount_type === 'percentage') {
      discountAmount = orderAmount * (parseFloat(validation.discount_value) / 100);
      if (validation.max_discount) {
        discountAmount = Math.min(discountAmount, parseFloat(validation.max_discount));
      }
    } else {
      discountAmount = parseFloat(validation.discount_value);
    }

    discountAmount = Math.min(discountAmount, orderAmount);

    res.json({
      valid: true,
      promo: {
        code: promoCode.toUpperCase(),
        discountType: validation.discount_type,
        discountValue: parseFloat(validation.discount_value),
        discountAmount: Math.round(discountAmount),
        finalAmount: orderAmount - Math.round(discountAmount)
      }
    });

  } catch (error) {
    console.error('Validate promo error:', error);
    res.status(500).json({
      valid: false,
      error: 'Failed to validate promo code'
    });
  }
});

/**
 * Get active promo codes (public)
 * GET /api/promo/active
 */
router.get('/promo/active', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT 
        code,
        description,
        discount_type,
        discount_value,
        max_discount_amount,
        min_order_amount,
        valid_until
      FROM promo_codes
      WHERE is_active = true
        AND valid_from <= NOW()
        AND (valid_until IS NULL OR valid_until >= NOW())
        AND (max_usage_total IS NULL OR current_usage_count < max_usage_total)
      ORDER BY created_at DESC
      LIMIT 10
    `);

    const promoCodes = result.rows.map(promo => ({
      code: promo.code,
      description: promo.description,
      type: promo.discount_type,
      value: parseFloat(promo.discount_value),
      maxDiscount: promo.max_discount_amount ? parseFloat(promo.max_discount_amount) : null,
      minOrder: promo.min_order_amount ? parseFloat(promo.min_order_amount) : null,
      validUntil: promo.valid_until
    }));

    res.json({
      success: true,
      promoCodes
    });

  } catch (error) {
    console.error('Get active promos error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get promo codes'
    });
  }
});

/**
 * Create new promo code (Admin only)
 * POST /api/admin/promo
 * 
 * Body:
 * {
 *   "code": "NEWYEAR25",
 *   "description": "New Year 25% discount",
 *   "discountType": "percentage",
 *   "discountValue": 25,
 *   "maxDiscountAmount": 100000,
 *   "minOrderAmount": 50000,
 *   "maxUsageTotal": 1000,
 *   "maxUsagePerUser": 1,
 *   "validUntil": "2025-01-31T23:59:59Z"
 * }
 */
router.post('/admin/promo', async (req, res) => {
  try {
    // TODO: Add admin authentication middleware
    
    const {
      code,
      description,
      discountType,
      discountValue,
      maxDiscountAmount,
      minOrderAmount,
      maxUsageTotal,
      maxUsagePerUser,
      validFrom,
      validUntil
    } = req.body;

    // Validate required fields
    if (!code || !discountType || !discountValue) {
      return res.status(400).json({
        success: false,
        error: 'Code, discount type, and discount value are required'
      });
    }

    // Validate discount type
    if (!['percentage', 'fixed_amount'].includes(discountType)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid discount type'
      });
    }

    // Insert promo code
    const result = await db.query(`
      INSERT INTO promo_codes (
        code, description, discount_type, discount_value,
        max_discount_amount, min_order_amount,
        max_usage_total, max_usage_per_user,
        valid_from, valid_until
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `, [
      code.toUpperCase(),
      description,
      discountType,
      discountValue,
      maxDiscountAmount || null,
      minOrderAmount || null,
      maxUsageTotal || null,
      maxUsagePerUser || 1,
      validFrom || new Date(),
      validUntil || null
    ]);

    res.json({
      success: true,
      promoCode: {
        id: result.rows[0].id,
        code: result.rows[0].code,
        description: result.rows[0].description,
        discountType: result.rows[0].discount_type,
        discountValue: parseFloat(result.rows[0].discount_value)
      }
    });

  } catch (error) {
    console.error('Create promo error:', error);
    
    if (error.code === '23505') { // Unique constraint violation
      return res.status(400).json({
        success: false,
        error: 'Promo code already exists'
      });
    }

    res.status(500).json({
      success: false,
      error: 'Failed to create promo code'
    });
  }
});

/**
 * Get promo usage statistics (Admin only)
 * GET /api/admin/promo/:code/stats
 */
router.get('/admin/promo/:code/stats', async (req, res) => {
  try {
    const { code } = req.params;

    // Get promo details
    const promoResult = await db.query(
      'SELECT * FROM promo_codes WHERE code = $1',
      [code.toUpperCase()]
    );

    if (promoResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Promo code not found'
      });
    }

    const promo = promoResult.rows[0];

    // Get usage statistics
    const statsResult = await db.query(`
      SELECT 
        COUNT(*) as total_uses,
        COUNT(DISTINCT user_email) as unique_users,
        SUM(discount_amount) as total_discount,
        AVG(discount_amount) as avg_discount,
        MIN(used_at) as first_used,
        MAX(used_at) as last_used
      FROM promo_code_usage
      WHERE promo_code_id = $1
    `, [promo.id]);

    const stats = statsResult.rows[0];

    // Get top users
    const topUsersResult = await db.query(`
      SELECT 
        user_email,
        COUNT(*) as usage_count,
        SUM(discount_amount) as total_saved
      FROM promo_code_usage
      WHERE promo_code_id = $1 AND user_email IS NOT NULL
      GROUP BY user_email
      ORDER BY usage_count DESC, total_saved DESC
      LIMIT 10
    `, [promo.id]);

    res.json({
      success: true,
      promo: {
        code: promo.code,
        description: promo.description,
        currentUsage: promo.current_usage_count,
        maxUsage: promo.max_usage_total
      },
      stats: {
        totalUses: parseInt(stats.total_uses),
        uniqueUsers: parseInt(stats.unique_users),
        totalDiscount: parseFloat(stats.total_discount) || 0,
        avgDiscount: parseFloat(stats.avg_discount) || 0,
        firstUsed: stats.first_used,
        lastUsed: stats.last_used
      },
      topUsers: topUsersResult.rows.map(user => ({
        email: user.user_email,
        usageCount: parseInt(user.usage_count),
        totalSaved: parseFloat(user.total_saved)
      }))
    });

  } catch (error) {
    console.error('Get promo stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get promo statistics'
    });
  }
});

module.exports = router;
